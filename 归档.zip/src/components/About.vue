<template>
    <div>
        <!-- banner -->
	<div class="banner about-banner">
		<banner></banner>
		<div class="about-heading">	
			<div class="container">
				<h2>简介</h2>
			</div>
		</div>
	</div>
	<!-- //banner -->
	<!-- about -->
	<div class="about">
		<!-- about-top -->
		<div class="agileits-about-top">
			<div class="container">
				<div class="agileits-about-top-heading">
					<h3>关于我们</h3>
				</div>
				<div class="agileinfo-top-grids">
					<div class="col-sm-4 wthree-top-grid">
						<img src="http://47.102.116.29:5050/image/head/head001.jpg" alt="" />
						<h4>社团简介</h4>
						<p>同济大学猫咪同盟是一个【公益实践类】社团，致力于改善同济猫咪的生存环境。我们的宗旨是：让同济的猫咪生活更好，让同济的校园更加有爱。</p>
					</div>
					<div class="col-sm-4 wthree-top-grid">
						<img src="http://47.102.116.29:5050/image/head/head001.jpg" alt="" />
						<h4>日常活动</h4>
						<p>猫咪同盟积极协助校方解决校内流浪猫带来的问题、致力于改善同济猫咪的生存环境。我们平时的社团活动包括:给校内的猫咪喂食、绝育(控制数量以保障生活质量)，科普猫咪相关知识，与热心的同学们一起救助校内患病或受伤的猫咪，并为条件合适的猫咪寻找领养家庭等。</p>
					</div>
					<div class="col-sm-4 wthree-top-grid">
						<img src="http://47.102.116.29:5050/image/head/head001.jpg" alt="" />
						<h4>关于救助</h4>
						<p>救助猫咪很多时候不得不投入大量的人力财力资源，而在猫咪事故多发的季节，猫咪同盟也许无法承担全部的救助需要，如果有同学发现需要帮助的猫咪，建议在联系猫盟求助的同时，先根据自己的能力以及相关救助知识采取合适的救助措施。</p>
					</div>
					<div class="clearfix"> </div>
				</div>
			</div>
		</div>
		<!-- //about-top -->
		
		<!-- choose -->
		<div class="w3-agileits-choose">
			<div class="container">
				<div class="agileits-about-top-heading agileits-w3layouts-choose-heading">
					<h3>负责范围</h3>
				</div>
				<div class="agile-choose-grids">
					<div class="col-sm-4 agile-choose-grid">
						<div class="choose-icon">
							<i class="fa fa-user" aria-hidden="true"></i>
						</div>
						<div class="choose-info">
							<h4>医疗类</h4>
							<p>当领取到相关医院对流浪猫的绝育优惠券后，我们会捕捉尚未绝育且容易捕捉的猫咪，将其送往医院接受绝育。若有需要进行救治的猫咪，在将猫咪送入医院治疗后，医疗费用会通过猫盟渠道进行募捐收集。</p>
						</div>
					</div>
					<div class="col-sm-4 agile-choose-grid">
						<div class="choose-icon">
							<i class="fa fa-cogs" aria-hidden="true"></i>
						</div>
						<div class="choose-info">
							<h4>找领养</h4>
							<p>猫盟为校园内的猫咪们进行领养家庭的寻找与筛选。在有领养意向的人递交领养申请表后，猫盟会判定申请人是否适合领养猫咪，并进行后续的领养确认工作。</p>
						</div>
					</div>
					<div class="col-sm-4 agile-choose-grid">
						<div class="choose-icon">
							<i class="fa fa-thumbs-o-up" aria-hidden="true"></i>
						</div>
						<div class="choose-info">
							<h4>团购粮</h4>
							<p>社团内会定期进行相对优惠且保证猫粮来源的猫粮团购，由社团内成员自行分粮。猫粮供应商会将猫粮以流浪猫粮的优惠售出。</p>
						</div>
					</div>
				</div>	
			</div>
		</div>
		<!-- //choose -->
		<!-- team -->
		<div class="team">
			<div class="container">
				<div class="agile_team_grids">
					<div class="col-md-3 agile_team_grid">
						<div class="agile_team_grid_main">
							<img src="http://47.102.116.29:5050/image/head/head001.jpg" alt=" " class="img-responsive">
						</div>
						<div class="agile_team_grid1">
							<h3>社长猫</h3>
							<p>123456789@163.com</p>
						</div>
					</div>
					<div class="col-md-3 agile_team_grid">
						<div class="agile_team_grid_main">
							<img src="http://47.102.116.29:5050/image/head/head001.jpg" alt=" " class="img-responsive">
						</div>
						<div class="agile_team_grid1">
							<h3>财务猫 </h3>
							<p>11223344@qq.com </p>
						</div>
					</div>
					<div class="col-md-3 agile_team_grid three">
						<div class="agile_team_grid_main">
							<img src="http://47.102.116.29:5050/image/head/head001.jpg" alt=" " class="img-responsive">
						</div>
						<div class="agile_team_grid1">
							<h3>未知猫</h3>
							<p>1235467@163.com</p>
						</div>
					</div>
					<div class="col-md-3 agile_team_grid four">
						<div class="agile_team_grid_main">
							<img src="http://47.102.116.29:5050/image/head/head001.jpg" alt=" " class="img-responsive">
						</div>
						<div class="agile_team_grid1">
							<h3>冬泳猫</h3>
							<p>456456456@qq.com</p>
						</div>
					</div>
					<div class="clearfix"> </div>
				</div>
			</div>
            </div>
		<!-- //team -->
	</div>
	<!-- //about -->
    <buttom></buttom>
    </div>
</template>


<script>
import buttom from '@/components/Buttom'
import banner from '@/components/Banner'

export default {
  name: 'About',
  data(){
    console.log(this.loll)
    return{
      lol: this.loll
    }
  },
  components: {
		buttom,
		banner
		},
  created() {
    // <img src="http://47.102.116.29:5050/image/head/head001.jpg">
    this.axios.get('http://47.102.116.29/api/Images')
          .then((response) => {
            console.log("2231")
            console.log(response.data[0].imageUrl)
            this.loll='http://47.102.116.29:5050/'+response.data[0].imageUrl
            console.log(this.loll)
          })
  },
};
</script>