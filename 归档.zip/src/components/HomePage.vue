<template>
<div>
    <!-- banner -->
    <div class="banner">
        <div class="header">
            <div class="container">
                <div class="header-left">
                    <div class="w3layouts-logo">
                        <h1>
                            <a href="index.html">Cat <span>Club</span></a>
                        </h1>
                    </div>
                </div>
                <div class="header-right">
                    <div class="top-nav">
                        <nav class="navbar navbar-default">
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">

<span class="sr-only">Toggle navigation</span>

<span class="icon-bar"></span>

<span class="icon-bar"></span>

<span class="icon-bar"></span>

</button>
                            </div>
                            <!-- Collect the nav links, forms, and other content for toggling -->
                            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                <ul class="nav navbar-nav">
                                    <li>
                                        <router-link to="/">主页</router-link>
                                    </li>
                                    <li>
                                        <router-link to="/About">简介</router-link>
                                    </li>
                                    <li>
                                        <router-link to="/Adoptation">领养</router-link>
                                    </li>
                                    <li>
                                        <router-link to="/Gallery">相册</router-link>
                                    </li>
                                    <li>
                                        <router-link to="/Blog">活动</router-link>
                                    </li>
                                    <li>
                                        <router-link to="/Contact">联系我们</router-link>
                                    </li>
                                </ul>
                                <div class="clearfix"> </div>
                            </div>
                        </nav>
                    </div>
                    <div class="agileinfo-social-grids">
                        <ul>
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-rss"></i></a></li>
                            <li><a href="#"><i class="fa fa-vk"></i></a></li>
                        </ul>
                    </div>
                    <div class="clearfix"> </div>
                </div>
                <div class="clearfix"> </div>
            </div>
        </div>
        <div class="w3layouts-banner-slider">
            <div class="container">
                <div class="slider">
                    <div class="callbacks_container">
                        <ul class="rslides callbacks callbacks1" id="slider4">
                            <li>
                                <div class="agileits-banner-info">
                                    <h3>你好，我们是<br>(*´▽｀)ノ同济猫盟 <span>快来加入我们吧</span></h3>
                                    <div class="w3-button">
                                        <a href="single.html">更多</a>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="agileits-banner-info">
                                    <h3>这里是第二页这里是第二页<span>快来加入我们吧</span></h3>
                                    <div class="w3-button">
                                        <a href="single.html">更多</a>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <!--banner Slider starts Here-->
                </div>
            </div>
        </div>
    </div>
    <!-- //banner -->
    <!-- banner-bottom -->
    <div class="welcome">
        <div class="container">
            <div class="w3ls-heading">
                <h2>欢迎━(*｀∀´*)ノ亻!</h2>
            </div>
            <div class="welcome-grids">
                <div class="col-md-6 agile-welcome-grid">
                    <div class="grid">
                        <div class="col-md-6 agileits-left">
                            <figure class="effect-chico">
                                <img src="http://47.102.116.29:5050/image/head/head001.jpg" alt="" />
                                <figcaption>
                                    <h4>Proin nulla</h4>
                                    <p>Chico's main fear was missing the morning bus.</p>
                                </figcaption>
                            </figure>
                        </div>
                        <div class="col-md-6 agileits-left">
                            <figure class="effect-chico">
                                <img src="http://47.102.116.29:5050/image/head/head001.jpg" alt="" />
                                <figcaption>
                                    <h4>Nam ornare</h4>
                                    <p>Chico's main fear was missing the morning bus.</p>
                                </figcaption>
                            </figure>
                        </div>
                        <div class="clearfix"> </div>
                    </div>
                </div>
                <div class="col-md-6 agileinfo-welcome-right">
                    <h4>同济猫盟——致力于猫咪保护的公益类学生社团。</h4>
                    <p>嗨，我们是同济大学猫咪同盟，一个公益类学生社团，我们的宗旨是让同济的猫生活得更好，让同济的校园更加有爱。
                        <span>猫咪同盟积极协助校方解决校内流浪猫带来的问题、致力于改善同济猫咪的生存环境。我们很乐意提供任何救助方面的建议以及猫咪相关的知识！</span>
                    </p>
                </div>
                <div class="clearfix"> </div>
            </div>
        </div>
    </div>
    <!-- banner-bottom -->
    <!-- services -->
    <div class="services">
        <div class="container">
            <div class="w3ls-heading">
                <h3>社团说明</h3>
            </div>
            <div class="wthree-services-grids">
                <div class="col-md-6 w3ls-about-left">
                    <div class="agileits-icon-grid">
                        <div class="icon-left hvr-radial-out">
                            <i class="fa fa-bell" aria-hidden="true"></i>
                        </div>
                        <div class="icon-right">
                            <h5>社团简介</h5>
                            <p>猫盟是一个【公益实践类】社团，致力于改善同济猫咪的生存环境。我们的宗旨是：让同济的猫咪生活更好，让同济的校园更加有爱。</p>
                        </div>
                        <div class="clearfix"> </div>
                    </div>
                    <div class="agileits-icon-grid">
                        <div class="icon-left hvr-radial-out">
                            <i class="fa fa-heart" aria-hidden="true"></i>
                        </div>
                        <div class="icon-right">
                            <h5>成员分工</h5>
                            <p>财务：管理社团的资金和财产。设计：宣传和开发猫咪周边产品。救助：负责猫咪的绝育和医疗。宣传：官方微博和微信公众号运营。组织：社团活动的策划。</p>
                        </div>
                        <div class="clearfix"> </div>
                    </div>
                </div>
                <div class="col-md-6 w3ls-about-left">
                    <div class="agileits-icon-grid">
                        <div class="icon-left hvr-radial-out">
                            <i class="fa fa-user" aria-hidden="true"></i>
                        </div>
                        <div class="icon-right">
                            <h5>日常活动</h5>
                            <p>给校内的猫咪喂食、绝育(控制数量以保障生活质量)，科普猫咪相关知识，与热心的同学们一起救助猫咪，为猫咪寻找领养家庭等。</p>
                        </div>
                        <div class="clearfix"> </div>
                    </div>
                    <div class="agileits-icon-grid">
                        <div class="icon-left hvr-radial-out">
                            <i class="fa fa-thumbs-up" aria-hidden="true"></i>
                        </div>
                        <div class="icon-right">
                            <h5>相关福利</h5>
                            <p>所有猫盟成员可免费领取猫粮，解锁指定猫咖的优惠，神秘干事有机会低价获得猫盟周边。（多多关注qq群后续通知鸭∠(°▽°)）</p>
                        </div>
                        <div class="clearfix"> </div>
                    </div>
                </div>
                <div class="clearfix"> </div>
            </div>
        </div>
    </div>
    <!-- //services -->
    <!-- news -->
    <div class="news">
        <div class="container">
            <div class="w3ls-heading">
                <h3>News & Events</h3>
            </div>
            <div class="w3-agileits-news-grids">
                <div class="col-md-6 news-left">
                    <div class="w3-agile-news-date">
                        <div class="agile-news-icon">
                            <i class="fa fa-calendar" aria-hidden="true"></i>
                            <p v-if="blog1.actTime">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span v-text="blog1.actTime.slice(0,4)"></span>年<span v-text="blog1.actTime.slice(5,7)"></span>月<span v-text="blog1.actTime.slice(8,10)"></span>日</p>
                            <p v-else>暂无日期</p>
                        </div>
                        <div class="agileits-line"> </div>
                        <div class="agile-news-icon">
                            <a href="#"><i class="fa fa-comments-o" aria-hidden="true"></i></a>
                            <p><span v-if="blog1.adminId">2 comments</span><span v-else>匿名</span></p>
                        </div>
                    </div>
                    <div class="w3-agile-news-img">
                        <a href="single.html"><img :src="blog1.activityCover" alt="" /></a>
                        <h4><a href="single.html"><span v-if="blog1.activityTitle">{{blog1.activityTitle}}</span><span v-else>暂无标题</span></a></h4>
                        <p><span v-if="blog1.activityDescription">{{blog1.activityDescription}}</span><span v-else>暂无内容</span></p>
                    </div>
                    <div class="clearfix"> </div>
                </div>
                <div class="col-md-6 news-right">
                    <div class="news-right-grid">
                        <a href="single.html"><span v-if="blog2.activityTitle">{{blog2.activityTitle}}</span><span v-else>暂无标题</span></a>
                        <h5 v-if="blog2.actTime"><span v-text="blog2.actTime.slice(0,4)"></span>年&nbsp;<span v-text="blog2.actTime.slice(5,7)"></span>月<span v-text="blog2.actTime.slice(8,10)"></span>日</h5>
                        <h5 v-else>暂无时间</h5>
                        <p><span v-if="blog2.activityDescription">{{blog2.activityDescription}}</span><span v-else>暂无内容暂无内容暂无内容暂无内容暂无内容暂无内容暂无内容暂无内容暂无内容暂无内容暂无内容暂无内容暂无内容暂无内容暂无内容暂无内容暂无内容暂无内容暂无内容暂无内容暂无内容暂无内容暂无内容暂无内容暂无内容</span></p>
                    </div>
                    <div class="news-right-grid">
                        <a href="single.html"><span v-if="blog3.activityTitle">{{blog3.activityTitle}}</span><span v-else>暂无标题</span></a>
                        <h5 v-if="blog3.actTime"><span v-text="blog3.actTime.slice(0,4)"></span>年&nbsp;<span v-text="blog3.actTime.slice(5,7)"></span>月<span v-text="blog3.actTime.slice(8,10)"></span>日</h5>
                        <h5 v-else>暂无时间</h5>
                        <p><span v-if="blog3.activityDescription">{{blog3.activityDescription}}</span><span v-else>暂无内容</span></p>
                    </div>
                    <div class="news-right-grid">
                        <a href="single.html"><span v-if="blog4.activityTitle">{{blog4.activityTitle}}</span><span v-else>暂无标题</span></a>
                        <h5 v-if="blog4.actTime"><span v-text="blog4.actTime.slice(0,4)"></span>年&nbsp;<span v-text="blog4.actTime.slice(5,7)"></span>月<span v-text="blog4.actTime.slice(8,10)"></span>日</h5>
                        <h5 v-else>暂无时间</h5>
                        <p><span v-if="blog4.activityDescription">{{blog4.activityDescription}}</span><span v-else>暂无内容</span></p>
                    </div>
                </div>
                <div class="clearfix"> </div>
            </div>
        </div>
    </div>
    <buttom></buttom>
    <!-- //news -->
</div>
</template>

<script>
import buttom from '@/components/Buttom'
import banner from '@/components/Banner'

export default {
    name: 'HomePage',
    data() {
        return {
            blog1: {},
            blog2: {},
            blog3: {},
            blog4: {},
            blog5: {},
        }
    },
    components: {
        buttom,
        banner
    },
    methods: {
        async init() {
            var blogs = await this.api.getAllActivity()
            console.log(blogs)
            try {
                this.blog1 = blogs[0]
                this.blog1.activityCover = await this.api.getImage(this.blog1.activityCover)
                this.blog2 = blogs[1]
                this.blog2.activityCover = await this.api.getImage(this.blog2.activityCover)
                this.blog3 = blogs[2]
                this.blog3.activityCover = await this.api.getImage(this.blog3.activityCover)
                this.blog4 = blogs[3]
                this.blog4.activityCover = await this.api.getImage(this.blog4.activityCover)
                this.blog5 = blogs[4]
                this.blog5.activityCover = await this.api.getImage(this.blog5.activityCover)
            } catch (err) {
                console.log('news', err)
            }
            console.log(this.blog1)
        },
        slides() {
            $(function () {
                // Slideshow 4
                $("#slider4").responsiveSlides({
                    auto: true,
                    pager: true,
                    nav: true,
                    speed: 500,
                    namespace: "callbacks",
                    before: function () {
                        $('.events').append("<li>before event fired.</li>");
                    },
                    after: function () {
                        $('.events').append("<li>after event fired.</li>");
                    }
                });
            });
        }
    },
    mounted() {
        this.slides()
        this.init()
    },
};
</script>
