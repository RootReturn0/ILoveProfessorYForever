<template>
    <div>
        <!-- banner -->
	<div class="banner about-banner">
		<banner></banner>
		<div class="about-heading">	
			<div class="container">
				<h2>Our Blog</h2>
			</div>
		</div>
	</div>
	<!-- //banner -->
	<!-- blog -->
	<div class="blog">
		<!-- container -->
		<div class="container">
			<div class="blog-top-grids">
				<div class="col-md-8 blog-top-left-grid">
					<div class="left-blog">
						<div class="blog-left" v-for="blog in blogs.slice(blogLowIndex,blogHighIndex)" :key="blog">
							<div class="blog-left-left">
								<p>发布者 <span v-text="blog.name" style="color:red;"></span> &nbsp;&nbsp;<span v-text="blog.time"></span></p>
								<!-- <p>Posted By <a href="#">Admin</a> &nbsp;&nbsp; on June 2, 2015 &nbsp;&nbsp; <a href="#">Comments (10)</a></p> -->
								<a href="single.html"><img src="http://47.102.116.29:5050/image/head/head001.jpg" alt="" /></a>
							</div>
							<div class="blog-left-right">
								<a><p v-text="blog.title"></p></a>
								<p v-text="blog.text"></p>
							</div>
							<div class="clearfix"> </div>
						</div>
					</div>
					<nav>
						<ul class="pagination">
							<li>
								<a href="#" aria-label="Previous">
									<span aria-hidden="true">«</span>
								</a>
							</li>
							<li><a>1</a></li>
							<li><a href="#">2</a></li>
							<li><a href="#">3</a></li>
							<li><a href="#">4</a></li>
							<li><a href="#">5</a></li>
							<li>
								<a href="#" aria-label="Next">
									<span aria-hidden="true">»</span>
								</a>
							</li>
						</ul>
					</nav>
				</div>
				<div class="col-md-4 blog-top-right-grid">
					<!-- <div class="Categories">
						<h3>Categories</h3>
						<ul>
							<li><a href="#">Phasellus sem leo, interdum quis risus</a></li>
							<li><a href="#">Nullam egestas nisi id malesuada aliquet </a></li>
							<li><a href="#"> Donec condimentum purus urna venenatis</a></li>
							<li><a href="#">Ut congue, nisl id tincidunt lobor mollis</a></li>
							<li><a href="#">Cum sociis natoque penatibus et magnis</a></li>
							<li><a href="#">Suspendisse nec magna id ex pretium</a></li>
						</ul>
					</div> -->
					<div class="Categories">
						<h3>Archive</h3>
						<ul class="marked-list offs1">
							<li v-for="site in sites" :key="site"> <a href="#">{{site.name}}&nbsp;&nbsp;({{site.num}})</a></li>                        
						</ul>
					</div>
					<div class="comments">
						<h3>Recent Comments</h3>
						<div class="comments-text">
							<div class="col-md-3 comments-left">
								<img src="http://47.102.116.29:5050/image/head/head001.jpg" alt="" />
							</div>
							<div class="col-md-9 comments-right">
								<h5>Admin</h5>
								<a href="#">Phasellus sem leointerdum risus</a> 
								<p>March 16,2014 6:09:pm</p>
							</div>
							<div class="clearfix"> </div>
						</div>
						<div class="comments-text">
							<div class="col-md-3 comments-left">
								<img src="http://47.102.116.29:5050/image/head/head001.jpg" alt="" />
							</div>
							<div class="col-md-9 comments-right">
								<h5>Admin</h5>
								<a href="#">Phasellus sem leointerdum risus</a> 
								<p>March 16,2014 6:09:pm</p>
							</div>
							<div class="clearfix"> </div>
						</div>
						<div class="comments-text">
							<div class="col-md-3 comments-left">
								<img src="http://47.102.116.29:5050/image/head/head001.jpg" alt="" />
							</div>
							<div class="col-md-9 comments-right">
								<h5>Admin</h5>
								<a href="#">Phasellus sem leointerdum risus</a> 
								<p>March 16,2014 6:09:pm</p>
							</div>
							<div class="clearfix"> </div>
						</div>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
		<!-- //container -->
	</div>
	<!-- //blog -->
    <buttom></buttom>
    </div>    
</template>

<script>
import buttom from '@/components/Buttom'
import banner from '@/components/Banner'

export default {
  name: 'Blog',
  data(){
    return{
	  blogLowIndex:0,
	  blogHighIndex:3,
	  blogs:[],
	  sites:[]
    }
  },
  components: {
		buttom,
		banner
		},
  methods:{
	  init(){
		  this.axios.get('http://47.102.116.29/api/Activities/')
          .then((response) => {
			for(var i=0; i<response.data.length;i++){
				this.blogs.push({name: response.data[i].adminId, time: response.data[i].actTime.slice(0,10), title: response.data[i].activityTitle, text: response.data[i].activityDescription, cover: response.data[i].activityCover});
				var flag=true;
				for(var j=0;j<this.sites.length;j++){
					if(response.data[i].actTime.slice(0,7)==this.sites[j].name){
						this.sites[j].num++;
						flag=false;
						break;
					}
				}
				if(flag){
					this.sites.push({name: response.data[i].actTime.slice(0,7), num:1})
				}
				console.log('?!',this.sites.length,i)
			}
			if(blogs.length<3)
				blogHighIndex=blogs.length
			console.log(this.blogIndex)
          })
	  },
	  prePage(){
	  },
	  nextPage(){
		  this.blogIndex=this.blogs.length<3?this.blogs.length:this.blogIndex-3;
	  }
  },
  mounted() {
	this.init()
  },
  created() {
    // <img src="http://47.102.116.29:5050/image/head/head001.jpg">
    this.axios.get('http://47.102.116.29/api/Activities/')
          .then((response) => {
			this.blog1=response.data[0].adminId
			this.blog1Time=response.data[0].actTime.slice(0,4)+'年'+response.data[0].actTime.slice(5,7)+'月'+response.data[0].actTime.slice(8,10)+'日'
		  })
  },
};
</script>

// archive --need activityId