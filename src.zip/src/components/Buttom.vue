<<template>
    <div id="buttom">
        <!-- footer -->
	<footer>
		<div class="container">
			<div class="agileits-w3layouts-footer-grids">
				<div class="col-md-4 footer-left">
					<h3>
						<a href="index.html">Cat <span>Club</span></a>
					</h3>
					<div class="footer-social-grids">
						<ul>
							<li><a href="#"><i class="fa fa-facebook"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter"></i></a></li>
							<li><a href="#"><i class="fa fa-rss"></i></a></li>
						</ul>
					</div>
				</div>
				<div class="col-md-4 footer-left">
					<h4>Navigation</h4>
					<div class="col-md-6 footer-grid-left">
						<ul>
							<li><a class="active" href="index.html">Home</a></li>
							<li><a href="about.html">About</a></li>								
							<li><a href="gallery.html">Gallery</a></li>
							<li><a href="icons.html">Icons</a></li>
						</ul>
					</div>
					<div class="col-md-6 footer-grid-left">
						<ul>
							<li><a href="typography.html">Typography</a></li>
							<li><a href="blog.html">Blog</a></li>
							<li><a href="contact.html">Contact</a></li>
						</ul>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="col-md-4 footer-left">
					<h4>Newsletter</h4>
					<p>Subscribe With Us</p>
					<form action="#" method="post">
						<input type="email" placeholder="Subscribe" name="Subscribe" required="">
						<button class="btn1">Go</button>
					</form>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</footer>
	<!-- footer -->
    </div>
</template>>

<script>
export default {
  name: "Buttom",
};
</script>