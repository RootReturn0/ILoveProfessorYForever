<template>
    <div>
        <!-- banner -->
	<div class="banner about-banner">
		<banner></banner>
		<div class="about-heading">	
			<div class="container">
				<h2>About Us</h2>
			</div>
		</div>
	</div>
	<!-- //banner -->
	<!-- about -->
	<div class="about">
		<!-- about-top -->
		<div class="agileits-about-top">
			<div class="container">
				<div class="agileits-about-top-heading">
					<h3>Who we are</h3>
				</div>
				<div class="agileinfo-top-grids">
					<div class="col-sm-4 wthree-top-grid">
						<img src="http://47.102.116.29:5050/image/head/head001.jpg" alt="" />
						<h4>Curabitur non blandit justo</h4>
						<p>Pellentesque auctor euismod lectus a pretium. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Curabitur ut elit at est tempus volutpat.nascetur ridiculus mus. Curabitur ut elit at est tempus volutpat.</p>
					</div>
					<div class="col-sm-4 wthree-top-grid">
						<img src="http://47.102.116.29:5050/image/head/head001.jpg" alt="" />
						<h4>Curabitur non blandit justo</h4>
						<p>Pellentesque auctor euismod lectus a pretium. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Curabitur ut elit at est tempus volutpat.nascetur ridiculus mus. Curabitur ut elit at est tempus volutpat.</p>
					</div>
					<div class="col-sm-4 wthree-top-grid">
						<img src="http://47.102.116.29:5050/image/head/head001.jpg" alt="" />
						<h4>Curabitur non blandit justo</h4>
						<p>Pellentesque auctor euismod lectus a pretium. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Curabitur ut elit at est tempus volutpat.nascetur ridiculus mus. Curabitur ut elit at est tempus volutpat.</p>
					</div>
					<div class="clearfix"> </div>
				</div>
			</div>
		</div>
		<!-- //about-top -->
		
		<!-- choose -->
		<div class="w3-agileits-choose">
			<div class="container">
				<div class="agileits-about-top-heading agileits-w3layouts-choose-heading">
					<h3>Why choose us?</h3>
				</div>
				<div class="agile-choose-grids">
					<div class="col-sm-4 agile-choose-grid">
						<div class="choose-icon">
							<i class="fa fa-user" aria-hidden="true"></i>
						</div>
						<div class="choose-info">
							<h4>Suspendisse ornare vitae ex nec aliquam</h4>
							<p>Nunc et massa ut purus porta euismod quis eu erat. Nam ornare faucibus elit sed tempor. Quisque iaculis odio nibh, et auctor tellus rhoncus vel. Maecenas arcu neque, semper eu commodo ut, pharetra vitae erat.</p>
						</div>
					</div>
					<div class="col-sm-4 agile-choose-grid">
						<div class="choose-icon">
							<i class="fa fa-cogs" aria-hidden="true"></i>
						</div>
						<div class="choose-info">
							<h4>Suspendisse ornare vitae ex nec aliquam</h4>
							<p>Nunc et massa ut purus porta euismod quis eu erat. Nam ornare faucibus elit sed tempor. Quisque iaculis odio nibh, et auctor tellus rhoncus vel. Maecenas arcu neque, semper eu commodo ut, pharetra vitae erat.</p>
						</div>
					</div>
					<div class="col-sm-4 agile-choose-grid">
						<div class="choose-icon">
							<i class="fa fa-thumbs-o-up" aria-hidden="true"></i>
						</div>
						<div class="choose-info">
							<h4>Suspendisse ornare vitae ex nec aliquam</h4>
							<p>Nunc et massa ut purus porta euismod quis eu erat. Nam ornare faucibus elit sed tempor. Quisque iaculis odio nibh, et auctor tellus rhoncus vel. Maecenas arcu neque, semper eu commodo ut, pharetra vitae erat.</p>
						</div>
					</div>
				</div>	
			</div>
		</div>
		<!-- //choose -->
		<!-- team -->
		<div class="team">
			<div class="container">
				<div class="agile_team_grids">
					<div class="col-md-3 agile_team_grid">
						<div class="agile_team_grid_main">
							<img src="http://47.102.116.29:5050/image/head/head001.jpg" alt=" " class="img-responsive">
							<div class="p-mask">
								<ul class="top-links two">
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
									<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
								</ul>
							</div>
						</div>
						<div class="agile_team_grid1">
							<h3>Riya John</h3>
							<p>Lorem ipsum</p>
						</div>
					</div>
					<div class="col-md-3 agile_team_grid">
						<div class="agile_team_grid_main">
							<img src="http://47.102.116.29:5050/image/head/head001.jpg" alt=" " class="img-responsive">
							<div class="p-mask">
								<ul class="top-links two">
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
									<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
								</ul>
							</div>
						</div>
						<div class="agile_team_grid1">
							<h3>Williamson </h3>
							<p>Consectetur </p>
						</div>
					</div>
					<div class="col-md-3 agile_team_grid three">
						<div class="agile_team_grid_main">
							<img src="http://47.102.116.29:5050/image/head/head001.jpg" alt=" " class="img-responsive">
							<div class="p-mask">
								<ul class="top-links two">
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
									<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
								</ul>
							</div>
						</div>
						<div class="agile_team_grid1">
							<h3>Rosy John</h3>
							<p>Suscipit</p>
						</div>
					</div>
					<div class="col-md-3 agile_team_grid four">
						<div class="agile_team_grid_main">
							<img src="http://47.102.116.29:5050/image/head/head001.jpg" alt=" " class="img-responsive">
							<div class="p-mask">
								<ul class="top-links two">
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
									<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
								</ul>
							</div>
						</div>
						<div class="agile_team_grid1">
							<h3>David Pal</h3>
							<p>Malesuada </p>
						</div>
					</div>
					<div class="clearfix"> </div>
				</div>
			</div>
            </div>
		<!-- //team -->
	</div>
	<!-- //about -->
    <buttom></buttom>
    </div>
</template>


<script>
import buttom from '@/components/Buttom'
import banner from '@/components/Banner'

export default {
  name: 'About',
  data(){
    console.log(this.loll)
    return{
      lol: this.loll
    }
  },
  components: {
		buttom,
		banner
		},
  created() {
    // <img src="http://47.102.116.29:5050/image/head/head001.jpg">
    this.axios.get('http://47.102.116.29/api/Images')
          .then((response) => {
            console.log("2231")
            console.log(response.data[0].imageUrl)
            this.loll='http://47.102.116.29:5050/'+response.data[0].imageUrl
            console.log(this.loll)
          })
  },
};
</script>